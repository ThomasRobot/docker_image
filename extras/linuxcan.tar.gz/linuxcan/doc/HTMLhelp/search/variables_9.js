var searchData=
[
  ['overruns',['overruns',['../structcan_bus_statistics__s.html#a07399a434cb184982f6edb5976762e7f',1,'canBusStatistics_s']]]
];
