var searchData=
[
  ['handle',['HANDLE',['../linlib_8h.html#a5ff89741beb6f252c7fdc9ca12bd9784',1,'HANDLE():&#160;linlib.h'],['../kvmlib_8h.html#aa8c0374618b33785ccb02f74bcfebc46',1,'HANDLE():&#160;kvmlib.h']]],
  ['handling_20bus_20errors',['Handling Bus Errors',['../page_user_guide_bus_errors.html',1,'page_user_guide']]]
];
