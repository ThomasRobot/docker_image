var searchData=
[
  ['initialization',['Initialization',['../group__kvaxml__initialization.html',1,'']]],
  ['initialization',['Initialization',['../group__kvm__initialization.html',1,'']]]
];
