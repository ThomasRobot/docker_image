var group__grp__kvlc =
[
    [ "Converter", "group__kvlc__converter.html", "group__kvlc__converter" ],
    [ "Output Formats", "group__kvlc__output.html", "group__kvlc__output" ],
    [ "Memorator", "group__kvlc__memorator.html", "group__kvlc__memorator" ],
    [ "Database", "group__kvlc__database.html", "group__kvlc__database" ]
];